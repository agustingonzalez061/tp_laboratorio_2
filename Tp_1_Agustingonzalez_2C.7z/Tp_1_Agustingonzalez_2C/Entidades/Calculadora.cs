﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace Entidades
{
    public class Calculadora
    {
        #region Metodos
        /// <summary>
        /// Método que valida los operadores aritmericos que se utilizan.
        /// </summary>
        /// <param name="operador">Cadena a validar</param>
        /// <returns>Cadena validada</returns>
        private static string ValidarOperador(string operador)
        {
            string retorno;
            switch (operador)
            {
                case "+":
                    retorno = "+";
                    break;
                case "-":
                    retorno = "-";
                    break;
                case "*":
                    retorno = "*";
                    break;
                case "/":
                    retorno = "/";
                    break;
                default:
                    retorno = "+";
                    break;
            }

            return retorno;
        }
        /// <summary>
        /// Valida, y realiza la operacion pedida entre los numeros pasados por parametro.
        /// </summary>
        /// <param name="num1">El primer numero se pasa como parametro</param>
        /// <param name="num2">El segundo numero se pasa como parametro</param>
        /// <param name="operador">El operador se pasa como parametro</param>
        /// <returns>retorna el resultado de la operacion</returns>
        public double Operar(Numero num1, Numero num2, string operador)
        {
            double resultado;
            switch (ValidarOperador(operador))
            {
                case "+":
                    resultado = num1 + num2;
                    break;
                case "-":
                    resultado = num1 - num2;
                    break;
                case "*":
                    resultado = num1 * num2;
                    break;
                case "/":
                    resultado = num1 / num2;
                    break;
                default:
                    resultado = 0;
                    break;

            }
            return resultado;
        }

        #endregion

    }
}
