﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace Entidades
{
    public class Numero
    {

        #region Atributo
        private double numero;
        #endregion
        #region Propiedad
        /// <summary>
        /// Valida que sea un numero valido y asigna el valor a el atributo numero
        /// </summary>
        private string setNumero
        {
            set { numero = ValidarNumero(value); }
        }
        #endregion
        #region constructor
        /// <summary>
        /// Constructor publico por default
        /// </summary>
        public Numero():this (0)
        {
        }
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="numero">Numero que recibe y llama al contructor que inicializa</param>
        public Numero(double Numero) : this (Numero.ToString())
        {
        }
        /// <summary>
        /// Constructor que inicializa el numero.
        /// </summary>
        /// <param name="strNumero">numero de tipo string</param>
        public Numero(string StrNumero)
        {
            setNumero = StrNumero;
        }
        #endregion
        #region Metodos
        /// <summary>
        /// Comprobará que el valor recibido sea numérico.
        /// </summary>
        /// <param name="strNumero">El numero a ser validado</param>
        /// <returns>Retorna el numero Validado, o retorna 0 en caso de error.</returns>
        private double ValidarNumero(string strNumero)
        {
            double retorno;
            bool verificarValor = double.TryParse(strNumero, out retorno);
            if (verificarValor != true)
            {
                retorno = 0;
            }
            return retorno;
        }
        /// <summary>
        /// Método que convierte un número Decimal en un binario en codigo ASCII
        /// </summary>
        /// <param name="numero">Numero a convertir. EJ: 3</param>
        /// <returns>Valor binario en codigo ASCII que es resultado de la conversion. EJ: 11</returns>
        public string DecimalBinario(string numero)
        {
            string retorno = "Error";
            for (int i = 0; i < numero.Length; i++)
            {
                if (!char.IsDigit(numero, i))
                    return retorno;
            }

            return DecimalBinario(double.Parse(numero));
        }

        /// <summary>
        /// Método que convierte un número Decimal en un binario en codigo ASCII
        /// </summary>
        /// <param name="numero">Número a convertir. EJ: 3</param>
        /// <returns>Valor binario en codigo ASCII que es resultado de la conversión. EJ: 11</returns>
        public string DecimalBinario(double numero)
        {
            string retorno = "";
            while (numero >= 2)
            {
                retorno = (numero % 2).ToString() + retorno;
                numero = (int)numero / 2;
            }

            return numero.ToString() + retorno;
        }
        /// <summary>
        /// Método que convierte un binario en codigo ASCII en un número entero
        /// </summary>
        /// <param name="binario">Binario en codigo ASCII a convertir. EJ: 11</param>
        /// <returns>Numero entero que es resultado de la conversión. EJ: 3</returns>
        public string BinarioDecimal(string binario)
        {
            string retorno = "Error";
            int num = 0;
            int i;

            for (i = 0; i < binario.Length; i++)
            {
                if (!char.IsDigit(binario, i))
                    return retorno;
            }

            for (i = 1; i <= binario.Length; i++)
            {
                num += int.Parse(binario[i - 1].ToString()) * (int)Math.Pow(2, binario.Length - i);
            }
            retorno = num.ToString();

            return retorno;
        }
        #endregion
        #region Sobrecarga
        /// <summary>
        /// Método que sobrecarga el operador +
        /// </summary>
        public static double operator +(Numero n1, Numero n2)
        {
            return n1.numero + n2.numero;
        }
        /// <summary>
        /// Método que sobrecarga el operador -
        /// </summary>
        public static double operator -(Numero n1, Numero n2)
        {
            return n1.numero - n2.numero;
        }
        /// <summary>
        /// Método que sobrecarga el operador *
        /// </summary>
        public static double operator *(Numero n1, Numero n2)
        {
            return n1.numero * n2.numero;
        }
        /// <summary>
        /// Método que sobrecarga el operador /
        /// </summary>
        public static double operator /(Numero n1, Numero n2)
        {
            double retornoAux = 0;
            if (n2.numero != 0)
            {
                retornoAux = n1.numero / n2.numero;
            }
            return retornoAux;
        }
        #endregion
    }
}
