﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tp_1_Agustingonzalez_2A
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
