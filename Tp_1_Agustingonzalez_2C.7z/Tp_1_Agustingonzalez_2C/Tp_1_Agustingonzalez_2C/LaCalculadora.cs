﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace Tp_1_Agustingonzalez_2A
{
    public partial class LaCalculadora : Form
    {
        private Numero _numero;
        public LaCalculadora()
        {
            InitializeComponent();
            this.CmbOperator.SelectedItem = "+";
            this.CmbOperator.Items.Add("+");
            this.CmbOperator.Items.Add("-");
            this.CmbOperator.Items.Add("*");
            this.CmbOperator.Items.Add("/");            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textNumero1.Font = new Font("", textNumero1.Font.Size * 2.1f);
            textNumero2.Font = new Font("", textNumero2.Font.Size * 2.1f);
            lblResultado.Font = new Font("", lblResultado.Font.Size * 2.9f);
            CmbOperator.Font = new Font("", CmbOperator.Font.Size * 2.7f);
        }

        private void textNumero1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textNumero2_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblResultado_Click(object sender, EventArgs e)
        {
            
        }

        private void btnOperar_Click(object sender, EventArgs e)
        {
            double result;
            result = Operar(textNumero1.Text,textNumero2.Text,CmbOperator.Text);
            lblResultado.Text = Convert.ToString(result);
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            textNumero1.Text = "";
            textNumero2.Text = "";
            lblResultado.Text = "";
            CmbOperator.Text = "";
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnConvertirABinario_Click(object sender, EventArgs e)
        {
            this._numero = new Numero(textNumero1.Text);
            lblResultado.Text = _numero.DecimalBinario(textNumero1.Text);
        }

        private void btnConvertirADecimal_Click(object sender, EventArgs e)
        {
            this._numero = new Numero(textNumero1.Text);
            lblResultado.Text = _numero.BinarioDecimal(textNumero1.Text);
        }
        private static double Operar(string num1, string num2, string operador)
        {
            double resultado;
            Calculadora calcu = new Calculadora();

            Numero _numero1 = new Numero(num1);
            Numero _numero2 = new Numero(num2);
            resultado = calcu.Operar(_numero1, _numero2, operador);
            return resultado;

        }
    }
}
