﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace MiCalculadora
{
    public partial class LaCalculadora : Form
    {
        private Numero _numero;
        public LaCalculadora()
        {
            InitializeComponent();
            
            this.CmbOperator.Items.Add("+");
            this.CmbOperator.Items.Add("-");
            this.CmbOperator.Items.Add("*");
            this.CmbOperator.Items.Add("/");
            this.CmbOperator.SelectedItem = "+";
        }

        private void btnOperar_Click(object sender, EventArgs e)
        {
            double result;
            result = Operar(textNumero1.Text, textNumero2.Text, CmbOperator.Text);
            lblResultado.Text = Convert.ToString(result);
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            this.Limpiar();
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnConvertirABinario_Click(object sender, EventArgs e)
        {
            this._numero = new Numero(lblResultado.Text);
            lblResultado.Text = _numero.DecimalBinario(lblResultado.Text);
        }

        private void btnConvertirADecimal_Click(object sender, EventArgs e)
        {
            this._numero = new Numero(lblResultado.Text);
            lblResultado.Text = _numero.BinarioDecimal(lblResultado.Text);
        }
        private static double Operar(string num1, string num2, string operador)
        {
            double resultado;
            Calculadora calcu = new Calculadora();

            Numero _numero1 = new Numero(num1);
            Numero _numero2 = new Numero(num2);
            resultado = calcu.Operar(_numero1, _numero2, operador);
            return resultado;

        }

        public void Limpiar()
        {
            textNumero1.Text = "";
            textNumero2.Text = "";
            lblResultado.Text = "";
            CmbOperator.Text = "";
        }
    }
}
